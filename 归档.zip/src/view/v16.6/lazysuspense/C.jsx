import React from "react";

class C extends React.Component {
  render() {
    return <div>CCCCCCCCCCC</div>;
  }
}

export default C;
