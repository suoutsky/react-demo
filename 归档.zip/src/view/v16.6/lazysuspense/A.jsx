import React from "react";
function A() {
  return <div>AAAAAAA </div>;
}

export default A;
