import React from 'react';
export default function ColorBox(props) {
   return (
       <div> 第四层{ props.theme }</div>
   )
}